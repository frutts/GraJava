import java.util.Scanner;
public class GraJednorekiBandyta {
    public static void main(String[] args) {
        JednorekiBandyta gra = new JednorekiBandyta();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj swoje imię:");
        String imie = scanner.nextLine();
        System.out.println("Witaj " + imie);
        System.out.println("Kluczem do wygranej jest wylosowanie trzech takich samych cyfr.");
        gra.graj();
        System.out.println("Koszt jednej gry to: " +
                gra.getKosztJednejGry() + "zł");
        System.out.println("Wygrana bazowa z jednej gry to: " +
                gra.getBazowaWygrana() + "zł");
        int wygrane = gra.getWygranaZGry();
        if(wygrane > 0){
            System.out.println("Wygrałeś " + wygrane + "zł");
        } else {
            if(wygrane == 0){
                System.out.println("Wyszedłeś na zero");
            }else{
                System.out.println("Przegrałeś " + Math.abs(wygrane) +
                        "zł");
            }
        }
        System.out.println("Dziękuję za grę!");
    }
}