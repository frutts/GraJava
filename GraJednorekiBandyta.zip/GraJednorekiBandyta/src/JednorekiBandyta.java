import java.util.Objects;
import java.util.Random;
import java.util.Scanner;
public class JednorekiBandyta {
    private boolean bWygrana = false;
    private int cyfra1;
    private int cyfra2;
    private int cyfra3;
    private final int KOSZT_JEDNEJ_GRY;
    private final int BAZOWA_WYGRANA;
    private int bonus;
    private int aktualnyStan;
    private int wygranaZGry = 0;
    private final Random random = new Random();

    private final Scanner scanner = new Scanner(System.in);
    public JednorekiBandyta(){
        KOSZT_JEDNEJ_GRY = 2;
        BAZOWA_WYGRANA = 100;
    }
    private void policzWygrane(){
        bonus = generateRandomNumber(1, 100);
        if ((cyfra1 != cyfra2) || (cyfra2 != cyfra3)){
            bWygrana = false;
            wygranaZGry = wygranaZGry - KOSZT_JEDNEJ_GRY ;
            return;
        } else {
            wygranaZGry = wygranaZGry + BAZOWA_WYGRANA + bonus -
                    KOSZT_JEDNEJ_GRY ;
        }
        bWygrana = true;
    }
    private int generateRandomNumber(int start, int koniec) {
        return random.nextInt(koniec - start + 1) + start;
    }
    public int getKosztJednejGry() {
        return KOSZT_JEDNEJ_GRY;
    }
    public int getWygranaZGry() {
        return wygranaZGry;
    }
    public int getBazowaWygrana() {
        return BAZOWA_WYGRANA;
    }
    public void graj() {
        String INSTRUKCJA = "Zaczynamy grę: Jednoręki Bandyta. Życzę Ci powodzenia!";
        System.out.println(INSTRUKCJA);
        aktualnyStan = generateRandomNumber(100, 200);
        while (true) {
            bWygrana = false;
            String DRUGA_INSTRUKCJA = "\nNaciśnij ENTER aby zawalczyć o wygraną lub wpisz \"KONIEC\" aby zakończyć grę";
            System.out.println(DRUGA_INSTRUKCJA);
            String Odp = scanner.nextLine();
            if (Objects.equals(Odp, "KONIEC")) {
                String KONIEC_GRY = "To jest koniec gry";
                System.out.println(KONIEC_GRY);
                return;
            }
            zakrec();
            policzWygrane();
            zapiszWygrane();
        }
    }
    private void zapiszWygrane() {
        int stanKonta;
        if (bWygrana) {

            System.out.println("ALe masz szczęście!");
            System.out.println("Koszt jednej gry: " + KOSZT_JEDNEJ_GRY);
            System.out.println("Bazowa wygrana: " + BAZOWA_WYGRANA);
            System.out.println("Bonus za tą grę: " + bonus);
            System.out.println("Twoj zysk lub strata: " + wygranaZGry);
            stanKonta = aktualnyStan + BAZOWA_WYGRANA + bonus -
                    KOSZT_JEDNEJ_GRY;
        }else{
            System.out.println("Nie tym razem!");
            System.out.println("Koszt jednej gry: " + KOSZT_JEDNEJ_GRY);
            System.out.println("Twoj zysk / strata: " + wygranaZGry);
            stanKonta = aktualnyStan - KOSZT_JEDNEJ_GRY;
        }
        aktualnyStan = stanKonta;
        System.out.println(stanKonta + " - aktualny stan konta");
        if (stanKonta <= 1){
            System.out.println("Jestes splukany - koniec gry!");
            System.exit(0);
        }
    }
    private void zakrec() {
        System.out.println("Stan konta przed tym zagraniem: " +
                aktualnyStan);
        cyfra1 = random.nextInt(3);
        cyfra2 = random.nextInt(3);
        cyfra3 = random.nextInt(3);
        System.out.println("\n " + cyfra1 + " | " + cyfra2 + " | " + cyfra3);
        System.out.println();
    }
}
